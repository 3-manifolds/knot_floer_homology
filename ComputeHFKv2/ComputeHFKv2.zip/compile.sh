g++ -std=c++11 -O3 Main.cpp Utility.cpp Min.cpp Max.cpp Crossing.cpp Simplify.cpp HomologyRank.cpp Report.cpp Diagrams.cpp Alternating.cpp KnotFloer.cpp 


